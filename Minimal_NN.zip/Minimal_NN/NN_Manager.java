public class NN_Manager
{
    private Vier_gewinnt game;
    private int population = 50;
    private double changeQuality = 50;
    private NN[] nets;
    private double sigmoidMax = 1;
    private double sigmoidMin = 0;
    
    public NN_Manager()
    {
        game = new Vier_gewinnt();
        nets = new NN[population];
        for (int i = 0; i < population; i++){
            nets[i] = new NN(game.inputNeurons, game.hiddenNeurons, game.outputNeurons, game.hiddenLayer, sigmoidMin, sigmoidMax);
            nets[i].randomWeights(-1, 1);
        }
    }
    
    public void train(int epochs){
        game.fieldprint = false;
        game.printWin = false;
        for (int i = 0; i < epochs; i++){
            System.out.println(i + "");
            theBest();
            change();
        }
    }
    
    public void change(){
        for (int i = 1; i < population; i++){
            nets[i].changeAll(changeQuality);
        }
        for (int i = 1; i < population; i++){
            nets[i].changeAll2(0.1);
        }
    }
    
    public void theBest(){
        int[] wins = allVSall();
        //for (int i = 0; i < population; i++){
        //    System.out.println(wins[i]);
        //}
        int n = 0;
        double temp = 0;
        for (int i = 0; i < population; i++){
            if (wins[i] >= temp){
                temp = wins[i];
                n = i;
            }
        }
        double[][] afterInputWeights = nets[n].getAfterInputWeights();
        double[][][] hiddenWeights = nets[n].getHiddenWeights();
        double[][] toOutputWeights = nets[n].getToOutputWeights();
        for (int i = 0; i < population; i++){
            if (i != n){
                nets[i].setWeights(afterInputWeights, hiddenWeights, toOutputWeights);
            }
        }
    }
    
    public int[] allVSall(){
        int[] wins = new int[population];
        for (int i = 0; i < population; i++){
            wins[i] = 0;
        }
        for (int i = 0; i < population; i++){
            for (int x = 0; x < population; x++){
                if (i != x){
                    int temp = netVSnet(i, x);
                    if (temp == 1){
                        wins[i]++;
                        wins[i]++;
                    }else if(temp == 2){
                        wins[x]++;
                        wins[x]++;
                    }else{
                        wins[i]++;
                        wins[x]++;
                    }
                }
            }
        }
        return wins;
    }
    
    private int netVSnet(int net1, int net2)
    {
        game.newGame();
        while (true){
            game.nnTurn(nets[net1].run(game.getInputVector()));
            if (game.won){
                return 1;
            }else if(game.lost){
                return 2;
            }else if(game.draw){
                return 0;
            }
            game.nnTurn(nets[net2].run(game.getInputVector()));
            if (game.won){
                return 2;
            }else if(game.lost){
                return 1;
            }else if(game.draw){
                return 0;
            }
        }
    }
    
    public void playerVSnet(){
        game.fieldprint = true;
        game.printWin = false;
        game.newGame();
    }
    public void playerVSnetTurn(int i){
        game.turn(i);
        if (game.won){
            System.out.println("You won!");
            return;
        }else if(game.lost){
            System.out.println("You lost!");
            return;
        }else if(game.draw){
            System.out.println("Draw!");
            return;
        }
        game.nnTurn(nets[1].run(game.getInputVector()));
        if (game.won){
            System.out.println("The KI won!");
            return;
        }else if(game.lost){
            System.out.println("The KI lost!");
            return;
        }else if(game.draw){
            System.out.println("Draw!");
            return;
        }
    }
    
}
