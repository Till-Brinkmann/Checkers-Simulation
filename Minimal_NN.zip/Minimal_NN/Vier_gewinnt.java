public class Vier_gewinnt
{
    private int[][] playfield = new int[7][6]; //7 Spalten 6 Zeilen
    public boolean printWin = false;
    public boolean lost = false;
    public boolean won = false;
    public boolean draw = false;
    public boolean fieldprint = false;
    public int inputNeurons = 7 * 6;
    public int outputNeurons = 7;
    public int hiddenNeurons = 7 * 6;
    public int hiddenLayer = 10;
    
    public Vier_gewinnt()
    {
    }
    
    public void newGame(){
        lost = false;
        won = false;
        for (int i = 0; i < 7; i++){
            for (int x = 0; x < 6; x++){
                playfield[i][x] = 0;
            }
        }
        if (fieldprint){
            printPlayfield();
        }
    }
    
    public double[] getInputVector(){
        double[] inputVector = new double[7*6];
        int n = 0;
        for (int x = 0; x < 7; x++){
            for (int y = 0; y < 6; y++){
                inputVector[n] = playfield[x][y];
                n++;
            }
        }
        /*for (int i = 0; i < 7*6; i++){
            System.out.println(inputVector[i]);
        }*/
        return inputVector;
    }
    
    public void nnTurn(double[] turnVector){
        int n = 0;
        double temp = 0;
        for (int i = 0; i < turnVector.length; i++){
            if (turnVector[i] >= temp){
                temp = turnVector[i];
                n = i;
            }
        }
        turn(n);
    }
    
    public void turn(int turnX){
        if (turnX >= 7){
            return;
        }
        lost = hasLoose(turnX);
        if (printWin && lost){
            System.out.println("You lost!");
        }
        if (lost){
            return;
        }
        int turnY = 5;
        while (turnY != -1 && playfield[turnX][5 - turnY] == 0){
            turnY --;
        }
        turnY ++;
        turnY = 5 - turnY;
        playfield[turnX][turnY] = 1;
        won = hasWon(turnX, turnY);
        if (won && printWin){
            System.out.println("Yout won!");
        }
        if (!won && !lost){
            draw = isDraw();
            if (printWin && draw){
                System.out.println("draw!");
            }
        }
        for (int i = 0; i < 7; i++){
            for (int x = 0; x < 6; x++){
                playfield[i][x] *= -1;
            }
        }
        if (fieldprint){
            printPlayfield();
        }
    }
    
    public void printPlayfield(){
    System.out.println("-----------------------------");
    for (int i = 0; i < 6; i++){
        System.out.println("| " + playfield[0][i] + " | " + playfield[1][i] + " | " + playfield[2][i] + " | " + playfield[3][i] + " | " + playfield[4][i] + " | " + playfield[5][i] + " | " + playfield[6][i] + " | ");
        System.out.println("-----------------------------");
    }
    }
    
    public boolean hasWon(int turnX, int turnY){
        if (four_in_a_row_in_a_row(playfield[turnX])){
            return true;
        }
        int[] testRow = new int[6];
        for (int i = 0; i < testRow.length; i++){
            testRow[i] = playfield[i][turnY];
        }
        if (four_in_a_row_in_a_row(testRow)){
            return true;
        }
        int startX = turnX;
        int startY = turnY;
        if (turnX < turnY){
            startY -= startX;
            startX = 0;
        }else{
            startX -= startY;
            startY = 0;
        }
        int rowlength = 0;
        while (startX < 7 && startY < 6){
            testRow[rowlength] = playfield[startX][startY];
            rowlength++;
            startX++;
            startY++;
        }
        for (int i = rowlength; i < 6; i++){
            testRow[i] = 0;
        }
        if (four_in_a_row_in_a_row(testRow)){
            return true;
        }
        startX = turnX;
        startY = turnY;
        if ((turnX) < (5 - turnY)){
            startY += startX;
            startX = 0;
        }else{
            startX -= 5 - startY;
            startY = 5;
        }
        rowlength = 0;
        while (startX < 7 && startY >= 0){
            testRow[rowlength] = playfield[startX][startY];
            rowlength++;
            startX++;
            startY--;
        }
        for (int i = rowlength; i < 6; i++){
            testRow[i] = 0;
        }
        if (four_in_a_row_in_a_row(testRow)){
            return true;
        }
        return false;
    }
    
    private boolean four_in_a_row_in_a_row(int[] row){
        //System.out.println(row[0] + " "+ row[1] + " " + row[2] + " " + row[3] + " " + row[4] + " " + row[5]);
        int testRowLength = 0;
        for (int i = 0; i < row.length; i++){
            if (testRowLength != 4){
                if (row[i] == 1){
                    testRowLength++;
                }else{
                    testRowLength = 0;
                }
            }
        }
        return (testRowLength == 4);
    }
    
    public boolean hasLoose(int turnX){
        return (playfield[turnX][0] != 0);
    }
    
    public boolean isDraw(){
        int usedFields = 0;
        for (int i = 0; i < 7; i++){
            for (int x = 0; x < 6; x++){
                if (playfield[i][x] != 0){
                    usedFields++;
                }
            }
        }
        if (usedFields == (7 * 6)){
            return true;
        }else{
            return false;
        }
    }
}
